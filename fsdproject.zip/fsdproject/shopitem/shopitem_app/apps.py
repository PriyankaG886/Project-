from django.apps import AppConfig


class ShopitemAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'shopitem_app'
